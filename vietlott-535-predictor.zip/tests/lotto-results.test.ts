import { describe, expect, it } from "vitest";

import { parseMirrorJsonl, parseOfficialHtml } from "../server/lotto-results";

describe("Lotto 5/35 result parsing", () => {
  it("parses the official history table format", () => {
    const html = `
      <table>
        <tr><td>11/09/2026</td><td><a href="/535?id=00879">00879</a></td><td>08 15 16 22 27 | 03</td></tr>
        <tr><td>10/09/2026</td><td>00878</td><td>16 22 26 27 34 | 12</td></tr>
      </table>
    `;

    expect(parseOfficialHtml(html, "https://vietlott.vn/official")).toEqual([
      {
        drawDate: "2026-09-11",
        drawId: "00879",
        numbers: [8, 15, 16, 22, 27],
        specialNumber: 3,
        sourceUrl: "https://vietlott.vn/official",
      },
      {
        drawDate: "2026-09-10",
        drawId: "00878",
        numbers: [16, 22, 26, 27, 34],
        specialNumber: 12,
        sourceUrl: "https://vietlott.vn/official",
      },
    ]);
  });

  it("parses mirror JSONL and keeps the five main numbers separate", () => {
    const jsonl = [
      JSON.stringify({ date: "2026-09-08", id: "00874", result: [4, 7, 14, 16, 23, 10] }),
      JSON.stringify({ date: "2026-09-08", id: "00873", result: [6, 7, 17, 19, 28, 1] }),
    ].join("\n");

    const results = parseMirrorJsonl(jsonl, "https://mirror.test/power535.jsonl");
    expect(results[0]).toMatchObject({ drawId: "00874", numbers: [4, 7, 14, 16, 23], specialNumber: 10 });
    expect(results[1]).toMatchObject({ drawId: "00873", numbers: [6, 7, 17, 19, 28], specialNumber: 1 });
  });

  it("parses packed official numbers", () => {
    const results = parseOfficialHtml("11/09/2026 00879 0815162227 | 03", "https://vietlott.vn/official");
    expect(results[0]).toMatchObject({ drawId: "00879", numbers: [8, 15, 16, 22, 27], specialNumber: 3 });
  });

  it("ignores malformed mirror rows", () => {
    const results = parseMirrorJsonl("not-json\n{}\n\n");
    expect(results).toEqual([]);
  });
});
