import { describe, expect, it } from "vitest";

import { buildEntry, getNumberStats, makeNumbers, type Strategy } from "../lib/predictor";

const strategies: Strategy[] = ["balanced", "spread", "random"];

describe("Vietlott 5/35 predictor", () => {
  it.each(strategies)("creates five unique sorted numbers for %s", (strategy) => {
    const numbers = makeNumbers(strategy);

    expect(numbers).toHaveLength(5);
    expect(new Set(numbers).size).toBe(5);
    expect(numbers.every((number) => number >= 1 && number <= 35)).toBe(true);
    expect(numbers).toEqual([...numbers].sort((a, b) => a - b));
  });

  it("spreads numbers across each 1–35 bucket", () => {
    const numbers = makeNumbers("spread");
    const buckets = numbers.map((number) => Math.floor((number - 1) / 7));

    expect(new Set(buckets)).toEqual(new Set([0, 1, 2, 3, 4]));
  });

  it("keeps the balanced strategy within a 2/3 parity and range split", () => {
    const numbers = makeNumbers("balanced");
    const stats = getNumberStats(numbers);

    expect(stats.odd).toBeGreaterThanOrEqual(2);
    expect(stats.odd).toBeLessThanOrEqual(3);
    expect(stats.low).toBeGreaterThanOrEqual(2);
    expect(stats.low).toBeLessThanOrEqual(3);
  });

  it("calculates summary statistics accurately", () => {
    expect(getNumberStats([2, 7, 18, 21, 34])).toEqual({
      odd: 2,
      even: 3,
      low: 2,
      high: 3,
      sum: 82,
    });
  });

  it("creates a history entry with strategy metadata", () => {
    const entry = buildEntry("random");

    expect(entry.strategy).toBe("random");
    expect(entry.id).toEqual(expect.any(String));
    expect(entry.createdAt).toEqual(expect.any(String));
    expect(entry.numbers).toHaveLength(5);
  });
});
