CREATE TABLE `lotto_results` (
	`id` int AUTO_INCREMENT NOT NULL,
	`drawId` varchar(16) NOT NULL,
	`drawDate` varchar(16) NOT NULL,
	`numbers` varchar(32) NOT NULL,
	`specialNumber` int NOT NULL,
	`sourceUrl` varchar(255) NOT NULL,
	`fetchedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lotto_results_id` PRIMARY KEY(`id`),
	CONSTRAINT `lotto_results_drawId_unique` UNIQUE(`drawId`)
);
