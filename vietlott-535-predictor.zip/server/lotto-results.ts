import * as db from "./db";

export const OFFICIAL_HISTORY_URL = "https://vietlott.vn/vi/trung-thuong/ket-qua-trung-thuong/winning-number-535";
export const OFFICIAL_LATEST_URL = "https://vietlott.vn/vi/trung-thuong/ket-qua-trung-thuong/535.html";
const MIRROR_URL = "https://raw.githubusercontent.com/vietvudanh/vietlott-data/main/data/power535.jsonl";
const CACHE_TTL_MS = 15 * 60 * 1000;

export type LottoResultRecord = {
  drawId: string;
  drawDate: string;
  numbers: number[];
  specialNumber: number;
  sourceUrl: string;
  fetchedAt: string;
  sourceKind: "official" | "mirror";
};

type ParsedResult = Omit<LottoResultRecord, "fetchedAt" | "sourceKind">;

let memoryCache: LottoResultRecord[] = [];
let lastSyncAt = 0;

function normalizeDate(value: string) {
  const [day, month, year] = value.split("/");
  return `${year}-${month}-${day}`;
}

function isValidNumbers(numbers: number[]) {
  return numbers.length === 5 && numbers.every((number) => number >= 1 && number <= 35) && new Set(numbers).size === 5;
}

function uniqueResults(results: ParsedResult[]) {
  const byId = new Map<string, ParsedResult>();
  for (const result of results) {
    if (isValidNumbers(result.numbers) && result.specialNumber >= 1 && result.specialNumber <= 12) {
      byId.set(result.drawId, result);
    }
  }
  return [...byId.values()].sort((a, b) => Number(b.drawId) - Number(a.drawId));
}

function htmlToText(html: string) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/\s+/g, " ")
    .trim();
}

export function parseOfficialHtml(html: string, sourceUrl: string): ParsedResult[] {
  const text = htmlToText(html);
  const results: ParsedResult[] = [];
  const tablePattern = /(\d{2}\/\d{2}\/\d{4})\s+(\d{5})\s+(\d{2})\s+(\d{2})\s+(\d{2})\s+(\d{2})\s+(\d{2})\s+\|?\s*(\d{2})/g;
  let match: RegExpExecArray | null;
  while ((match = tablePattern.exec(text))) {
    results.push({
      drawDate: normalizeDate(match[1]),
      drawId: match[2],
      numbers: match.slice(3, 8).map(Number),
      specialNumber: Number(match[8]),
      sourceUrl,
    });
  }

  const packedPattern = /(\d{2}\/\d{2}\/\d{4})\s+(\d{5})\s+(\d{10})\s+\|?\s*(\d{2})/g;
  while ((match = packedPattern.exec(text))) {
    results.push({
      drawDate: normalizeDate(match[1]),
      drawId: match[2],
      numbers: match[3].match(/\d{2}/g)?.map(Number) ?? [],
      specialNumber: Number(match[4]),
      sourceUrl,
    });
  }

  const headlinePattern = /Kỳ quay thưởng\s*#?(\d{5})\s*ngày\s*(\d{2}\/\d{2}\/\d{4})\s+((?:\d{2}\s+){4}\d{2})\s+\|?\s*(\d{2})/gi;
  while ((match = headlinePattern.exec(text))) {
    results.push({
      drawDate: normalizeDate(match[2]),
      drawId: match[1],
      numbers: match[3].trim().split(/\s+/).map(Number),
      specialNumber: Number(match[4]),
      sourceUrl,
    });
  }

  return uniqueResults(results);
}

export function parseMirrorJsonl(content: string, sourceUrl = MIRROR_URL): ParsedResult[] {
  const results: ParsedResult[] = [];
  for (const line of content.split(/\r?\n/)) {
    if (!line.trim()) continue;
    try {
      const record = JSON.parse(line) as { date?: string; id?: string; result?: number[] };
      if (!record.date || !record.id || !Array.isArray(record.result) || record.result.length < 6) continue;
      results.push({
        drawDate: record.date,
        drawId: record.id,
        numbers: record.result.slice(0, 5).map(Number).sort((a, b) => a - b),
        specialNumber: Number(record.result[5]),
        sourceUrl,
      });
    } catch {
      // Ignore malformed lines so a single bad record cannot block refresh.
    }
  }
  return uniqueResults(results);
}

async function fetchText(url: string, timeoutMs = 8_000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      headers: { "user-agent": "Vietlott535Predictor/1.0" },
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.text();
  } finally {
    clearTimeout(timeout);
  }
}

function withMetadata(results: ParsedResult[], sourceKind: LottoResultRecord["sourceKind"], fetchedAt: string) {
  return results.map((result) => ({ ...result, sourceKind, fetchedAt }));
}

async function persistResults(results: LottoResultRecord[]) {
  await db.upsertLottoResults(
    results.slice(0, 20).map((result) => ({
      drawId: result.drawId,
      drawDate: result.drawDate,
      numbers: result.numbers.join(","),
      specialNumber: result.specialNumber,
      sourceUrl: result.sourceUrl,
      fetchedAt: new Date(result.fetchedAt),
    })),
  );
}

async function readStoredResults(limit = 20): Promise<LottoResultRecord[]> {
  const stored = await db.getRecentLottoResults(limit);
  if (stored.length > 0) {
    return stored.map((result) => ({
      drawId: result.drawId,
      drawDate: result.drawDate,
      numbers: result.numbers.split(",").map(Number),
      specialNumber: result.specialNumber,
      sourceUrl: result.sourceUrl,
      fetchedAt: result.fetchedAt.toISOString(),
      sourceKind: result.sourceUrl.includes("vietlott.vn") ? "official" : "mirror",
    }));
  }
  return memoryCache.slice(0, limit);
}

export async function getLottoResults(limit = 20) {
  const stored = await readStoredResults(limit);
  const newestFetchedAt = stored[0]?.fetchedAt ? Date.parse(stored[0].fetchedAt) : 0;
  if (stored.length > 0 && Date.now() - newestFetchedAt < CACHE_TTL_MS) return stored;

  try {
    const refreshed = await syncLottoResults();
    return refreshed.results.slice(0, limit);
  } catch {
    return stored;
  }
}

export async function syncLottoResults() {
  const fetchedAt = new Date().toISOString();
  const officialSources = [OFFICIAL_HISTORY_URL, OFFICIAL_LATEST_URL];
  const officialAttempts = await Promise.all(
    officialSources.map(async (sourceUrl) => {
      try {
        return { sourceUrl, results: parseOfficialHtml(await fetchText(sourceUrl, 4_000), sourceUrl) };
      } catch {
        return { sourceUrl, results: [] as ParsedResult[] };
      }
    }),
  );
  for (const attempt of officialAttempts) {
    if (attempt.results.length > 0) {
      const enriched = withMetadata(attempt.results, "official", fetchedAt);
      memoryCache = enriched;
      lastSyncAt = Date.now();
      await persistResults(enriched);
      return { results: enriched, syncedAt: fetchedAt, sourceKind: "official" as const, sourceUrl: attempt.sourceUrl, lastSyncAt };
    }
  }

  const mirrorResults = parseMirrorJsonl(await fetchText(MIRROR_URL, 8_000), MIRROR_URL);
  if (mirrorResults.length === 0) throw new Error("Không đọc được dữ liệu kết quả Lotto 5/35.");
  const enriched = withMetadata(mirrorResults, "mirror", fetchedAt);
  memoryCache = enriched;
  lastSyncAt = Date.now();
  await persistResults(enriched);
  return { results: enriched, syncedAt: fetchedAt, sourceKind: "mirror" as const, sourceUrl: MIRROR_URL, lastSyncAt };
}
