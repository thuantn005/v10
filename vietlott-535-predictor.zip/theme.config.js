/** @type {const} */
const themeColors = {
  primary: { light: '#1A9B70', dark: '#72E3AD' },
  background: { light: '#F7FBF8', dark: '#112322' },
  surface: { light: '#EEF7F1', dark: '#1A3430' },
  foreground: { light: '#173A3A', dark: '#E8F7EE' },
  muted: { light: '#6C817B', dark: '#A7C0B5' },
  border: { light: '#DCE9E1', dark: '#31534A' },
  success: { light: '#22A66D', dark: '#72E3AD' },
  warning: { light: '#C99038', dark: '#F4C66D' },
  error: { light: '#C96656', dark: '#F29483' },
};

module.exports = { themeColors };
