import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import { useEffect, useMemo, useState } from "react";
import {
  Alert,
  FlatList,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { buildEntry, getNumberStats, makeNumbers, type PickEntry, type Strategy } from "@/lib/predictor";
import { trpc } from "@/lib/trpc";

const HISTORY_KEY = "vietlott-535-history-v1";

const strategies: Array<{ key: Strategy; label: string; description: string }> = [
  { key: "balanced", label: "Cân bằng", description: "Chẵn/lẻ · thấp/cao" },
  { key: "spread", label: "Phủ dải", description: "Trải đều 1–35" },
  { key: "random", label: "Ngẫu nhiên", description: "Không thiên lệch" },
];

const strategyLabels: Record<Strategy, string> = {
  balanced: "Cân bằng",
  spread: "Phủ dải",
  random: "Ngẫu nhiên",
};

function formatTime(isoDate: string) {
  return new Intl.DateTimeFormat("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(isoDate));
}

function formatDrawDate(isoDate: string) {
  return new Intl.DateTimeFormat("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" }).format(
    new Date(`${isoDate}T12:00:00`),
  );
}

function countMatches(numbers: number[], resultNumbers: number[] | undefined) {
  if (!resultNumbers) return 0;
  return numbers.filter((number) => resultNumbers.includes(number)).length;
}

function NumberBall({ value, muted = false }: { value: number; muted?: boolean }) {
  return (
    <View style={[styles.numberBall, muted && styles.numberBallMuted]}>
      <Text style={[styles.numberText, muted && styles.numberTextMuted]}>
        {String(value).padStart(2, "0")}
      </Text>
    </View>
  );
}

function StatItem({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <View style={styles.statItem}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statDetail}>{detail}</Text>
    </View>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const resultsQuery = trpc.lotto.latest.useQuery(undefined, {
    staleTime: 15 * 60 * 1000,
    refetchOnMount: "always",
  });
  const syncMutation = trpc.lotto.sync.useMutation({
    onSuccess: () => resultsQuery.refetch(),
  });
  const [strategy, setStrategy] = useState<Strategy>("balanced");
  const [currentNumbers, setCurrentNumbers] = useState<number[]>(() => makeNumbers("balanced"));
  const [history, setHistory] = useState<PickEntry[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const latestResult = resultsQuery.data?.[0];

  useEffect(() => {
    AsyncStorage.getItem(HISTORY_KEY)
      .then((stored) => {
        if (stored) {
          const parsed = JSON.parse(stored) as PickEntry[];
          if (Array.isArray(parsed)) {
            setHistory(parsed.slice(0, 8));
            if (parsed[0]?.numbers?.length === 5) {
              setCurrentNumbers(parsed[0].numbers);
              setStrategy(parsed[0].strategy);
            }
          }
        }
      })
      .catch(() => undefined)
      .finally(() => setIsLoaded(true));
  }, []);

  const currentStats = useMemo(() => getNumberStats(currentNumbers), [currentNumbers]);

  const syncResults = () => {
    syncMutation.mutate();
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => undefined);
    }
  };

  const persistHistory = (nextHistory: PickEntry[]) => {
    setHistory(nextHistory);
    AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(nextHistory)).catch(() => undefined);
  };

  const generate = (amount = 1) => {
    const nextEntries = Array.from({ length: amount }, () => buildEntry(strategy));
    setCurrentNumbers(nextEntries[0].numbers);
    persistHistory([...nextEntries, ...history].slice(0, 8));
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => undefined);
    }
  };

  const selectStrategy = (nextStrategy: Strategy) => {
    setStrategy(nextStrategy);
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => undefined);
    }
  };

  const clearHistory = () => {
    Alert.alert("Xóa lịch sử?", "Các bộ số đã tạo trên thiết bị sẽ bị xóa.", [
      { text: "Hủy", style: "cancel" },
      {
        text: "Xóa",
        style: "destructive",
        onPress: () => {
          persistHistory([]);
          AsyncStorage.removeItem(HISTORY_KEY).catch(() => undefined);
        },
      },
    ]);
  };

  const header = (
    <View>
      <View style={styles.hero}>
        <View style={styles.heroTopRow}>
          <View style={styles.brandMark}>
            <Text style={styles.brandMarkText}>5</Text>
          </View>
          <View style={styles.statusPill}>
            <View style={styles.statusDot} />
            <Text style={styles.statusText}>THAM KHẢO</Text>
          </View>
        </View>
        <Text style={styles.eyebrow}>LOTTO 5/35 · BẢNG ĐIỀU KHIỂN</Text>
        <Text style={styles.title}>Chọn số có chiến lược.</Text>
        <Text style={styles.heroCopy}>
          Tạo bộ số tham khảo bằng các nguyên tắc cân bằng đơn giản. Không có thuật toán nào biết trước kết quả.
        </Text>
      </View>

      <View style={styles.sectionHeader}>
        <View>
          <Text style={styles.sectionKicker}>01 · PHƯƠNG PHÁP</Text>
          <Text style={styles.sectionTitle}>Bạn muốn chọn theo cách nào?</Text>
        </View>
      </View>
      <View style={styles.strategyGrid}>
        {strategies.map((item) => {
          const active = strategy === item.key;
          return (
            <Pressable
              key={item.key}
              accessibilityRole="button"
              onPress={() => selectStrategy(item.key)}
              style={({ pressed }) => [
                styles.strategyCard,
                { borderColor: active ? colors.primary : colors.border },
                active && { backgroundColor: colors.primary },
                pressed && styles.pressed,
              ]}
            >
              <Text style={[styles.strategyLabel, active && styles.strategyLabelActive]}>{item.label}</Text>
              <Text style={[styles.strategyDescription, active && styles.strategyDescriptionActive]}>
                {item.description}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <View style={styles.sectionHeaderWithMargin}>
        <View>
          <Text style={styles.sectionKicker}>02 · GỢI Ý HIỆN TẠI</Text>
          <Text style={styles.sectionTitle}>Bộ số của bạn</Text>
        </View>
        <Text style={styles.liveLabel}>{isLoaded ? "ĐÃ SẴN SÀNG" : "ĐANG TẢI"}</Text>
      </View>

      <View style={[styles.pickCard, { backgroundColor: colors.surface }]}>
        <View style={styles.pickCardTop}>
          <View>
            <Text style={styles.pickCardKicker}>LỰA CHỌN {strategyLabels[strategy].toUpperCase()}</Text>
            <Text style={styles.pickCardTitle}>Một bộ · 5 số</Text>
          </View>
          <View style={styles.shuffleBadge}>
            <Text style={styles.shuffleBadgeText}>↗</Text>
          </View>
        </View>
        <View style={styles.numbersRow}>
          {currentNumbers.map((number) => (
            <NumberBall key={number} value={number} />
          ))}
        </View>
        <View style={styles.pickMetaRow}>
          <Text style={styles.pickMeta}>Tổng {currentStats.sum}</Text>
          <Text style={styles.pickMeta}>•</Text>
          <Text style={styles.pickMeta}>{currentStats.odd} lẻ · {currentStats.even} chẵn</Text>
          <Text style={styles.pickMeta}>•</Text>
          <Text style={styles.pickMeta}>{currentStats.low} thấp · {currentStats.high} cao</Text>
        </View>
      </View>

      <View style={styles.actionRow}>
        <Pressable
          accessibilityRole="button"
          onPress={() => generate(1)}
          style={({ pressed }) => [styles.primaryButton, pressed && styles.buttonPressed]}
        >
          <Text style={styles.primaryButtonText}>Tạo bộ số mới</Text>
          <Text style={styles.primaryButtonArrow}>→</Text>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          onPress={() => generate(3)}
          style={({ pressed }) => [styles.secondaryButton, { borderColor: colors.border }, pressed && styles.buttonPressed]}
        >
          <Text style={styles.secondaryButtonText}>+3 bộ</Text>
        </Pressable>
      </View>

      <View style={styles.insightCard}>
        <View style={styles.insightIcon}>
          <Text style={styles.insightIconText}>i</Text>
        </View>
        <View style={styles.insightCopy}>
          <Text style={styles.insightTitle}>Xác suất không đổi</Text>
          <Text style={styles.insightText}>
            Mỗi bộ 5 số có xác suất lý thuyết như nhau: 1 trên 324.632. Thống kê chỉ giúp bạn chọn có chủ đích hơn.
          </Text>
        </View>
      </View>

      <View style={styles.sectionHeaderWithMargin}>
        <View>
          <Text style={styles.sectionKicker}>03 · KẾT QUẢ CHÍNH THỨC</Text>
          <Text style={styles.sectionTitle}>Đối chiếu kỳ mới nhất</Text>
        </View>
        <Pressable
          onPress={syncResults}
          disabled={syncMutation.isPending}
          accessibilityRole="button"
          style={({ pressed }) => [styles.refreshButton, pressed && styles.pressed]}
        >
          <Text style={styles.refreshButtonText}>{syncMutation.isPending ? "ĐANG CẬP NHẬT" : "CẬP NHẬT"}</Text>
        </Pressable>
      </View>

      {latestResult ? (
        <View style={[styles.officialCard, { backgroundColor: colors.surface }]}>
          <View style={styles.officialTopRow}>
            <View>
              <Text style={styles.officialKicker}>
                {latestResult.sourceKind === "official" ? "NGUỒN VIETLOTT" : "BẢN SAO ĐỒNG BỘ · CHỜ XÁC NHẬN"}
              </Text>
              <Text style={styles.officialTitle}>Kỳ #{latestResult.drawId}</Text>
            </View>
            <Text style={styles.officialDate}>{formatDrawDate(latestResult.drawDate)}</Text>
          </View>
          <View style={styles.numbersRow}>
            {latestResult.numbers.map((number) => (
              <NumberBall key={`result-${number}`} value={number} />
            ))}
          </View>
          <View style={styles.officialBottomRow}>
            <Text style={styles.officialMeta}>Số đặc biệt {String(latestResult.specialNumber).padStart(2, "0")}</Text>
            <Pressable
              onPress={() => Linking.openURL(latestResult.sourceUrl).catch(() => undefined)}
              accessibilityRole="link"
              style={({ pressed }) => pressed && styles.pressed}
            >
              <Text style={styles.sourceLink}>Mở nguồn ↗</Text>
            </Pressable>
          </View>
        </View>
      ) : (
        <View style={styles.officialEmpty}>
          <Text style={styles.officialEmptyTitle}>Chưa có dữ liệu kết quả</Text>
          <Text style={styles.officialEmptyText}>Bấm “Cập nhật” để thử đồng bộ lại từ nguồn Vietlott.</Text>
        </View>
      )}
      {syncMutation.error && <Text style={styles.syncError}>Không đồng bộ được lúc này. Dữ liệu cũ vẫn được giữ lại.</Text>}

      <View style={styles.sectionHeaderWithMargin}>
        <View>
          <Text style={styles.sectionKicker}>04 · ĐỌC NHANH</Text>
          <Text style={styles.sectionTitle}>Cân bằng bộ số</Text>
        </View>
      </View>
      <View style={styles.statsGrid}>
        <StatItem label="LẺ / CHẴN" value={`${currentStats.odd} / ${currentStats.even}`} detail="nhịp số" />
        <StatItem label="THẤP / CAO" value={`${currentStats.low} / ${currentStats.high}`} detail="mốc 17" />
        <StatItem label="TỔNG" value={String(currentStats.sum)} detail="trên 175" />
      </View>

      <View style={styles.historyHeader}>
        <View>
          <Text style={styles.sectionKicker}>05 · TRÊN THIẾT BỊ</Text>
          <Text style={styles.sectionTitle}>Lịch sử tạo số</Text>
        </View>
        {history.length > 0 && (
          <Pressable onPress={clearHistory} accessibilityRole="button" style={({ pressed }) => pressed && styles.pressed}>
            <Text style={styles.clearText}>Xóa tất cả</Text>
          </Pressable>
        )}
      </View>
    </View>
  );

  return (
    <ScreenContainer className="px-5" containerClassName="bg-background">
      <FlatList
        data={history}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={[styles.historyRow, { borderBottomColor: colors.border }]}>
            <View style={styles.historyNumbers}>
              {item.numbers.map((number) => (
                <NumberBall key={`${item.id}-${number}`} value={number} muted />
              ))}
            </View>
            <View style={styles.historyInfo}>
              <Text style={styles.historyStrategy}>{strategyLabels[item.strategy]}</Text>
              <Text style={styles.matchText}>
                {latestResult ? `${countMatches(item.numbers, latestResult.numbers)}/5 trùng` : "Chưa đối chiếu"}
              </Text>
              <Text style={styles.historyDate}>{formatTime(item.createdAt)}</Text>
            </View>
          </View>
        )}
        ListHeaderComponent={header}
        ListEmptyComponent={<Text style={styles.emptyHistory}>Chưa có lần tạo nào được lưu. Bấm “Tạo bộ số mới” để bắt đầu.</Text>}
        ListFooterComponent={
          <View style={styles.footer}>
            <Text style={styles.footerTitle}>Chơi có trách nhiệm</Text>
            <Text style={styles.footerText}>
              Ứng dụng chỉ tạo số tham khảo cho mục đích giải trí. Hãy đặt ngân sách trước khi chơi và không xem đây là cách kiếm tiền.
            </Text>
            <Text style={styles.footerVersion}>VIETLOTT 5/35 · LOCAL MODE · V1.0</Text>
          </View>
        }
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  listContent: { paddingTop: 18, paddingBottom: 34 },
  hero: { paddingTop: 2, paddingBottom: 27 },
  heroTopRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 24 },
  brandMark: { width: 39, height: 39, borderRadius: 13, backgroundColor: "#163B3A", alignItems: "center", justifyContent: "center" },
  brandMarkText: { color: "#B8F6D2", fontSize: 19, fontWeight: "800" },
  statusPill: { flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 11, paddingVertical: 7, borderRadius: 99, backgroundColor: "#E7F5EC" },
  statusDot: { width: 7, height: 7, borderRadius: 99, backgroundColor: "#19A66A" },
  statusText: { color: "#227252", fontSize: 10, fontWeight: "800", letterSpacing: 1.1 },
  eyebrow: { color: "#2E8377", fontSize: 11, fontWeight: "800", letterSpacing: 1.3, marginBottom: 9 },
  title: { color: "#15383A", fontSize: 32, lineHeight: 37, fontWeight: "800", letterSpacing: -0.7, maxWidth: 315 },
  heroCopy: { color: "#66777A", fontSize: 14, lineHeight: 21, marginTop: 12, maxWidth: 350 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 13 },
  sectionHeaderWithMargin: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginTop: 31, marginBottom: 13 },
  sectionKicker: { color: "#6B8A85", fontSize: 10, fontWeight: "800", letterSpacing: 1.15, marginBottom: 5 },
  sectionTitle: { color: "#173A3A", fontSize: 19, lineHeight: 24, fontWeight: "700" },
  strategyGrid: { flexDirection: "row", gap: 8 },
  strategyCard: { flex: 1, minHeight: 76, borderWidth: 1, borderRadius: 15, paddingHorizontal: 10, paddingVertical: 12, justifyContent: "space-between", backgroundColor: "#FFFFFF" },
  strategyLabel: { color: "#2A4B4B", fontSize: 13, fontWeight: "800" },
  strategyDescription: { color: "#81908F", fontSize: 10, lineHeight: 14, marginTop: 7 },
  strategyLabelActive: { color: "#F2FFF6" },
  strategyDescriptionActive: { color: "#C6F1D9" },
  pressed: { opacity: 0.7 },
  liveLabel: { color: "#2F9A72", fontSize: 9, fontWeight: "800", letterSpacing: 0.9, paddingBottom: 3 },
  pickCard: { borderRadius: 20, padding: 18, shadowColor: "#173B3A", shadowOpacity: 0.08, shadowRadius: 14, shadowOffset: { width: 0, height: 7 }, elevation: 2 },
  pickCardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  pickCardKicker: { color: "#4A8178", fontSize: 10, fontWeight: "800", letterSpacing: 1.1 },
  pickCardTitle: { color: "#193D3C", fontSize: 16, fontWeight: "700", marginTop: 4 },
  shuffleBadge: { width: 30, height: 30, borderRadius: 10, backgroundColor: "#E8F6ED", alignItems: "center", justifyContent: "center" },
  shuffleBadgeText: { color: "#168060", fontSize: 19, fontWeight: "700" },
  numbersRow: { flexDirection: "row", justifyContent: "space-between", marginTop: 23 },
  numberBall: { width: 47, height: 47, borderRadius: 99, backgroundColor: "#173E3D", alignItems: "center", justifyContent: "center" },
  numberBallMuted: { width: 29, height: 29, backgroundColor: "#E7F2ED" },
  numberText: { color: "#D7F9E3", fontSize: 16, fontWeight: "800", letterSpacing: -0.4 },
  numberTextMuted: { color: "#337669", fontSize: 10 },
  pickMetaRow: { flexDirection: "row", alignItems: "center", gap: 7, marginTop: 17, flexWrap: "wrap" },
  pickMeta: { color: "#758987", fontSize: 11, fontWeight: "600" },
  actionRow: { flexDirection: "row", gap: 9, marginTop: 12 },
  primaryButton: { flex: 1, minHeight: 52, borderRadius: 15, backgroundColor: "#1A9B70", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 12 },
  primaryButtonText: { color: "#F1FFF6", fontSize: 14, fontWeight: "800" },
  primaryButtonArrow: { color: "#BDF7D4", fontSize: 20, marginTop: -2 },
  secondaryButton: { width: 76, minHeight: 52, borderRadius: 15, borderWidth: 1, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" },
  secondaryButtonText: { color: "#1D625A", fontSize: 13, fontWeight: "800" },
  buttonPressed: { transform: [{ scale: 0.97 }], opacity: 0.9 },
  insightCard: { flexDirection: "row", alignItems: "flex-start", backgroundColor: "#EFF8F1", borderRadius: 16, padding: 14, marginTop: 15, gap: 11 },
  insightIcon: { width: 24, height: 24, borderRadius: 99, backgroundColor: "#C7EBD4", alignItems: "center", justifyContent: "center" },
  insightIconText: { color: "#247253", fontSize: 14, fontWeight: "800" },
  insightCopy: { flex: 1 },
  insightTitle: { color: "#276B54", fontSize: 12, fontWeight: "800", marginBottom: 4 },
  insightText: { color: "#648075", fontSize: 11, lineHeight: 17 },
  refreshButton: { paddingBottom: 3, paddingHorizontal: 3 },
  refreshButtonText: { color: "#2F9A72", fontSize: 9, fontWeight: "800", letterSpacing: 0.9 },
  officialCard: { borderRadius: 20, padding: 18, shadowColor: "#173B3A", shadowOpacity: 0.06, shadowRadius: 12, shadowOffset: { width: 0, height: 6 }, elevation: 1 },
  officialTopRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  officialKicker: { color: "#4A8178", fontSize: 9, fontWeight: "800", letterSpacing: 0.9 },
  officialTitle: { color: "#193D3C", fontSize: 17, fontWeight: "800", marginTop: 4 },
  officialDate: { color: "#7F9690", fontSize: 11, fontWeight: "700", paddingTop: 2 },
  officialBottomRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 16 },
  officialMeta: { color: "#758987", fontSize: 11, fontWeight: "600" },
  sourceLink: { color: "#1A9B70", fontSize: 11, fontWeight: "800" },
  officialEmpty: { borderWidth: 1, borderColor: "#DCE9E1", borderRadius: 16, padding: 16, backgroundColor: "#FFFFFF" },
  officialEmptyTitle: { color: "#35655D", fontSize: 12, fontWeight: "800", marginBottom: 4 },
  officialEmptyText: { color: "#84938F", fontSize: 11, lineHeight: 17 },
  syncError: { color: "#B26B52", fontSize: 10, lineHeight: 15, marginTop: 7 },
  statsGrid: { flexDirection: "row", borderWidth: 1, borderColor: "#E2EBE5", borderRadius: 16, backgroundColor: "#FFFFFF", paddingVertical: 15 },
  statItem: { flex: 1, paddingHorizontal: 13, borderRightWidth: 1, borderRightColor: "#E9EFEB" },
  statItemLast: { borderRightWidth: 0 },
  statLabel: { color: "#7A918B", fontSize: 9, fontWeight: "800", letterSpacing: 0.7 },
  statValue: { color: "#1B4C46", fontSize: 18, fontWeight: "800", marginTop: 7 },
  statDetail: { color: "#9AA9A4", fontSize: 10, marginTop: 3 },
  historyHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end", marginTop: 31, marginBottom: 8 },
  clearText: { color: "#B26B52", fontSize: 11, fontWeight: "700", paddingBottom: 3 },
  historyRow: { minHeight: 64, borderBottomWidth: 1, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  historyNumbers: { flexDirection: "row", gap: 5 },
  historyInfo: { alignItems: "flex-end" },
  historyStrategy: { color: "#356A61", fontSize: 11, fontWeight: "800" },
  matchText: { color: "#1A9B70", fontSize: 10, fontWeight: "800", marginTop: 3 },
  historyDate: { color: "#9AA8A4", fontSize: 10, marginTop: 4 },
  emptyHistory: { color: "#839490", fontSize: 12, lineHeight: 18, paddingVertical: 18, paddingHorizontal: 2 },
  footer: { marginTop: 31, paddingTop: 20, borderTopWidth: 1, borderTopColor: "#E3EBE5" },
  footerTitle: { color: "#35655D", fontSize: 12, fontWeight: "800", marginBottom: 5 },
  footerText: { color: "#84938F", fontSize: 11, lineHeight: 17 },
  footerVersion: { color: "#B0BCB8", fontSize: 9, fontWeight: "800", letterSpacing: 0.9, marginTop: 17 },
});
