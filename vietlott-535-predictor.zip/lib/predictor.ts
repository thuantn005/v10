export type Strategy = "balanced" | "spread" | "random";

export type PickEntry = {
  id: string;
  numbers: number[];
  strategy: Strategy;
  createdAt: string;
};

function shuffle(values: number[]) {
  const result = [...values];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result;
}

function pickFromPool(pool: number[], amount: number) {
  return shuffle(pool).slice(0, amount);
}

export function makeNumbers(strategy: Strategy): number[] {
  const allNumbers = Array.from({ length: 35 }, (_, index) => index + 1);

  if (strategy === "random") {
    return shuffle(allNumbers).slice(0, 5).sort((a, b) => a - b);
  }

  if (strategy === "spread") {
    const buckets = [
      Array.from({ length: 7 }, (_, index) => index + 1),
      Array.from({ length: 7 }, (_, index) => index + 8),
      Array.from({ length: 7 }, (_, index) => index + 15),
      Array.from({ length: 7 }, (_, index) => index + 22),
      Array.from({ length: 7 }, (_, index) => index + 29),
    ];
    return buckets.map((bucket) => pickFromPool(bucket, 1)[0]).sort((a, b) => a - b);
  }

  for (let attempt = 0; attempt < 40; attempt += 1) {
    const numbers = shuffle(allNumbers).slice(0, 5).sort((a, b) => a - b);
    const oddCount = numbers.filter((number) => number % 2 === 1).length;
    const lowCount = numbers.filter((number) => number <= 17).length;
    if (oddCount >= 2 && oddCount <= 3 && lowCount >= 2 && lowCount <= 3) {
      return numbers;
    }
  }

  return [4, 11, 18, 27, 34];
}

export function getNumberStats(numbers: number[]) {
  const odd = numbers.filter((number) => number % 2 === 1).length;
  const low = numbers.filter((number) => number <= 17).length;
  const sum = numbers.reduce((total, number) => total + number, 0);
  return { odd, even: numbers.length - odd, low, high: numbers.length - low, sum };
}

export function buildEntry(strategy: Strategy): PickEntry {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    numbers: makeNumbers(strategy),
    strategy,
    createdAt: new Date().toISOString(),
  };
}
